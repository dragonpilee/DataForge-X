
import streamlit as st
import pandas as pd
import requests
import matplotlib.pyplot as plt

# 🧠 Connect to LM Studio (Phi-4 Mini)
def ask_phi4(prompt):
    try:
        res = requests.post(
            "http://localhost:1234/completion",  # LM Studio endpoint
            json={"prompt": prompt, "temperature": 0.5, "max_tokens": 512}
        )
        return res.json().get("text", "").strip()
    except Exception as e:
        return f"❌ Error: {e}"

# 🎯 Streamlit UI
st.set_page_config(page_title="InsightAI", layout="wide")
st.title("📊 InsightAI – Offline Data Analyst (Phi-4 Mini)")

uploaded_file = st.file_uploader("📂 Upload your CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.subheader("📋 Dataset Preview")
    st.dataframe(df.head(20))

    query = st.text_input("🤖 Ask a question about the data (e.g., 'Which product sold the most?')")

    if query:
        st.markdown("🔍 Generating answer...")
        prompt = (
            f"You are a data analyst AI. Analyze the following data and answer the user's question.\n\n"
            f"DataFrame Head:\n{df.head(10).to_string(index=False)}\n\n"
            f"User Question: {query}\n\n"
            f"Answer clearly and suggest code if applicable."
        )
        output = ask_phi4(prompt)
        st.markdown("### 💡 AI Insight")
        st.markdown(output)

    st.markdown("### 📊 Optional: Quick Plot")
    with st.expander("Create a simple plot"):
        col1, col2 = st.columns(2)
        with col1:
            x_col = st.selectbox("X-axis column", df.columns)
        with col2:
            y_col = st.selectbox("Y-axis column", df.columns)

        if x_col and y_col:
            fig, ax = plt.subplots()
            df.plot(kind='bar', x=x_col, y=y_col, ax=ax)
            st.pyplot(fig)
else:
    st.info("Upload a CSV file to get started.")
